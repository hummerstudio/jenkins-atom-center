import java.nio.file.Files;
import java.nio.file.Path;

public class NativeAtom {
    public static void main(String[] args) throws Exception {
        Path ws = Path.of(System.getenv("atom_workspace"));
        Files.writeString(ws.resolve("report.json"), "{\"bugs\":0}");
        Files.createDirectories(ws.resolve("coverage"));
        Files.writeString(ws.resolve("coverage/index.html"),
                "<html><body style='font-family:sans-serif;padding:24px'>"
                + "<h2>Coverage</h2><p>Statements 92% · Branches 78% · Functions 95%</p>"
                + "<table border=1 cellpadding=6 style='border-collapse:collapse'>"
                + "<tr><th>file</th><th>stmts</th></tr><tr><td>DemoAtom.java</td><td>92%</td></tr>"
                + "<tr><td>DemoParam.java</td><td>100%</td></tr></table></body></html>");
        String json = "{\"status\":\"success\",\"message\":\"built demo package\",\"data\":{"
                + "\"branch\":{\"type\":\"string\",\"value\":\"main\"},"
                + "\"artifactUrl\":{\"type\":\"string\",\"value\":\"https://example.com/sdk-demo-1.0.0.jar\"},"
                + "\"token\":{\"type\":\"string\",\"value\":\"tkn_live_9f2c41d0\",\"isSensitive\":true},"
                + "\"package\":{\"type\":\"artifact\",\"value\":[\"report.json\"]},"
                + "\"coverage\":{\"type\":\"report\",\"label\":\"Coverage report\",\"path\":\"coverage\"},"
                + "\"dashboard\":{\"type\":\"report\",\"label\":\"Build dashboard\",\"url\":\"https://example.com/dashboard\"}}}";
        Files.writeString(Path.of(System.getenv("atom_data_output")), json);
    }
}
